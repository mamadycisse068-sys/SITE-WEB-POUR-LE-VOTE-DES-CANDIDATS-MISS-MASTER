# GUINÉE MISS & MASTER VOTE 2026

Prototype web complet et déployable du concours « Votre voix, leur couronne 👑 ».

## Stack
- Node.js + Express
- SQLite + better-sqlite3
- HTML/CSS/JavaScript mobile-first
- JWT + cookie HttpOnly pour l'administration
- Helmet, validation serveur et transactions SQLite
- Architecture de paiement par adaptateur
- Paiement DEMO par défaut : **aucun clic ne doit être considéré comme un paiement réel**

## Démarrage local

1. Installer Node.js 20+.
2. Copier `.env.example` vers `.env`.
3. Modifier au minimum `JWT_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`.
4. Exécuter :
   ```bash
   npm install
   npm start
   ```
5. Ouvrir `http://localhost:3000`.

Au premier démarrage, la base SQLite est créée dans `data/vote.sqlite` et les candidats DEMO sont insérés.

## Administration
- URL : `/admin.html`
- Identifiants : ceux définis dans `.env`.
- Le tableau de bord permet de gérer candidats, prix, commission, transactions et export CSV.

## Paiement DEMO
Le prototype crée une transaction unique `TX-...`, mais le bouton « Confirmer le paiement DEMO » appelle une route serveur dédiée qui simule un retour fournisseur. Il ne s'agit PAS d'un paiement réel.
Les votes ne sont ajoutés que dans la transaction serveur après vérification du statut `PAID`.

## Passage au réel
1. Obtenir les accès marchands officiels du prestataire de paiement choisi.
2. Implémenter l'adaptateur correspondant dans `server.js` (création de paiement + vérification/webhook).
3. Configurer les variables d'environnement.
4. Faire vérifier les signatures/webhooks côté serveur.
5. Tester les statuts `PENDING`, `PAID`, `FAILED`, `CANCELLED`, les retries et l'idempotence.
6. Désactiver complètement le mode DEMO en production.
7. Configurer HTTPS, domaine, sauvegardes SQLite ou migrer vers PostgreSQL si le trafic devient important.
8. Remplacer les données DEMO par les vrais candidats et leurs photos.

## Déploiement
Le projet peut être déployé sur un serveur Node.js/VPS ou une plateforme compatible Node. Pour une base durable et un trafic important, PostgreSQL est recommandé.

### Variables de production
- `NODE_ENV=production`
- `JWT_SECRET` long et aléatoire
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `PAYMENT_MODE=LIVE`
- `PUBLIC_BASE_URL=https://vote.votredomaine.com`
- identifiants du fournisseur de paiement

### Domaine
Acheter un domaine, par exemple `missmastervote2026.com`, puis pointer son DNS vers l'hébergeur. Activer HTTPS.

## Sécurité importante
Le prototype protège les opérations d'administration et le changement d'état d'une transaction par contrôle serveur. Pour le concours réel, le prestataire de paiement doit fournir une confirmation serveur-à-serveur/webhook ou une API de vérification officielle. Ne jamais accepter un statut `PAID` fourni directement par le navigateur.
