import express from "express";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import jwt from "jsonwebtoken";
import bcrypt from "crypto";
import Database from "better-sqlite3";
import { v4 as uuidv4 } from "uuid";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME";
const app = express();

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "vote.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL CHECK(category IN ('MISS','MASTER')),
  number INTEGER NOT NULL,
  name TEXT NOT NULL,
  presentation TEXT NOT NULL,
  photo_url TEXT,
  votes INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(category, number)
);
CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY,
  candidate_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  unit_price INTEGER NOT NULL,
  gross_amount INTEGER NOT NULL,
  commission_type TEXT NOT NULL CHECK(commission_type IN ('FIXED','PERCENT')),
  commission_value REAL NOT NULL,
  commission_amount INTEGER NOT NULL,
  contest_amount INTEGER NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  payment_method TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PENDING','PAID','FAILED','CANCELLED')),
  provider_reference TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at TEXT,
  FOREIGN KEY(candidate_id) REFERENCES candidates(id)
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  transaction_id TEXT,
  action TEXT NOT NULL,
  metadata TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

function setDefault(key, value) {
  db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)").run(key, String(value));
}
setDefault("vote_price", 1000);
setDefault("commission_type", "PERCENT");
setDefault("commission_value", 10);

const hashPassword = (password) => bcrypt.createHash("sha256").update(password + JWT_SECRET).digest("hex");
const adminEmail = process.env.ADMIN_EMAIL || "admin@example.com";
const adminPassword = process.env.ADMIN_PASSWORD || "ChangeMe123!";
if (!db.prepare("SELECT id FROM admins WHERE email=?").get(adminEmail)) {
  db.prepare("INSERT INTO admins(email,password_hash) VALUES(?,?)").run(adminEmail, hashPassword(adminPassword));
}

const demo = [
  ["MISS",1,"Aïcha Camara","Candidate DEMO — présentation fictive en attendant les candidates officielles.","https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=700&q=80"],
  ["MISS",2,"Mariama Bah","Candidate DEMO — présentation fictive en attendant les candidates officielles.","https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=700&q=80"],
  ["MISS",3,"Fatoumata Diallo","Candidate DEMO — présentation fictive en attendant les candidates officielles.","https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=700&q=80"],
  ["MISS",4,"Hawa Condé","Candidate DEMO — présentation fictive en attendant les candidates officielles.","https://images.unsplash.com/photo-1524250502761-1ac6f2e30d43?auto=format&fit=crop&w=700&q=80"],
  ["MASTER",1,"Mamadou Cissé","Candidat DEMO — présentation fictive en attendant les candidats officiels.","https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=700&q=80"],
  ["MASTER",2,"Ibrahima Bah","Candidat DEMO — présentation fictive en attendant les candidats officiels.","https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=700&q=80"],
  ["MASTER",3,"Mohamed Camara","Candidat DEMO — présentation fictive en attendant les candidats officiels.","https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=700&q=80"],
  ["MASTER",4,"Abdoulaye Sylla","Candidat DEMO — présentation fictive en attendant les candidats officiels.","https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=700&q=80"]
];
const insertCandidate = db.prepare("INSERT OR IGNORE INTO candidates(category,number,name,presentation,photo_url) VALUES(?,?,?,?,?)");
for (const c of demo) insertCandidate.run(...c);

function getSettings() {
  const rows = db.prepare("SELECT key,value FROM settings").all();
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
}
function calculate(quantity, settings) {
  const unit = Number(settings.vote_price);
  const gross = quantity * unit;
  const type = settings.commission_type;
  const value = Number(settings.commission_value);
  const commission = type === "FIXED" ? value : Math.round(gross * value / 100);
  return { unit, gross, commission, contest: gross - commission, type, value };
}
function ranking(category) {
  return db.prepare(`
    SELECT id, category, number, name, presentation, photo_url, votes,
           ROW_NUMBER() OVER (ORDER BY votes DESC, number ASC) position
    FROM candidates WHERE category=? AND active=1
    ORDER BY votes DESC, number ASC
  `).all(category);
}
function auth(req,res,next) {
  const token = req.cookies.admin_token;
  if (!token) return res.status(401).json({error:"Non authentifié"});
  try { req.admin = jwt.verify(token, JWT_SECRET); next(); }
  catch { return res.status(401).json({error:"Session invalide"}); }
}

app.get("/api/settings/public", (req,res) => {
  const s = getSettings();
  res.json({ votePrice:Number(s.vote_price), paymentMode:process.env.PAYMENT_MODE || "DEMO" });
});

app.get("/api/candidates", (req,res) => {
  const category = (req.query.category || "").toUpperCase();
  const search = String(req.query.search || "").trim();
  let sql = "SELECT id,category,number,name,presentation,photo_url,votes,active FROM candidates WHERE active=1";
  const args = [];
  if (["MISS","MASTER"].includes(category)) { sql += " AND category=?"; args.push(category); }
  if (search) { sql += " AND (name LIKE ? OR CAST(number AS TEXT)=?)"; args.push(`%${search}%`, search); }
  sql += " ORDER BY votes DESC, number ASC";
  const rows = db.prepare(sql).all(...args);
  const out = rows.map((r,i)=>({...r, position:i+1}));
  res.json(out);
});

app.get("/api/candidates/:id", (req,res) => {
  const row = db.prepare("SELECT id,category,number,name,presentation,photo_url,votes,active FROM candidates WHERE id=? AND active=1").get(req.params.id);
  if (!row) return res.status(404).json({error:"Candidat introuvable"});
  const pos = db.prepare("SELECT COUNT(*) c FROM candidates WHERE category=? AND active=1 AND votes>?").get(row.category,row.votes).c + 1;
  res.json({...row, position:pos});
});

app.post("/api/transactions", (req,res) => {
  const {candidateId, quantity, customerName, customerPhone, customerEmail="", paymentMethod="ORANGE_MONEY"} = req.body;
  const q = Number(quantity);
  if (!Number.isInteger(q) || q < 1 || q > 1000) return res.status(400).json({error:"Nombre de votes invalide"});
  const candidate = db.prepare("SELECT * FROM candidates WHERE id=? AND active=1").get(candidateId);
  if (!candidate) return res.status(404).json({error:"Candidat introuvable"});
  if (!customerName?.trim() || !customerPhone?.trim()) return res.status(400).json({error:"Nom et téléphone requis"});
  const calc = calculate(q, getSettings());
  const id = "TX-" + new Date().toISOString().replace(/\D/g,"").slice(0,14) + "-" + uuidv4().slice(0,8).toUpperCase();
  db.prepare(`
    INSERT INTO transactions(id,candidate_id,quantity,unit_price,gross_amount,commission_type,commission_value,commission_amount,contest_amount,customer_name,customer_phone,customer_email,payment_method,status)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'PENDING')
  `).run(id,candidate.id,q,calc.unit,calc.gross,calc.type,calc.value,calc.commission,calc.contest,customerName.trim(),customerPhone.trim(),customerEmail.trim(),paymentMethod);
  db.prepare("INSERT INTO audit_logs(transaction_id,action,metadata) VALUES(?,?,?)").run(id,"TRANSACTION_CREATED",JSON.stringify({candidateId:q, paymentMethod}));
  res.status(201).json({transactionId:id, status:"PENDING", candidate:{id:candidate.id,name:candidate.name,category:candidate.category,number:candidate.number}, ...calc, paymentMode:process.env.PAYMENT_MODE || "DEMO"});
});

app.post("/api/transactions/:id/demo-confirm", (req,res) => {
  if ((process.env.PAYMENT_MODE || "DEMO") !== "DEMO") return res.status(403).json({error:"Mode DEMO désactivé"});
  const tx = db.prepare("SELECT * FROM transactions WHERE id=?").get(req.params.id);
  if (!tx) return res.status(404).json({error:"Transaction introuvable"});
  if (tx.status !== "PENDING") return res.status(409).json({error:"Transaction déjà traitée", status:tx.status});
  const providerRef = "DEMO-PROVIDER-" + uuidv4().slice(0,12).toUpperCase();
  const finalize = db.transaction(() => {
    db.prepare("UPDATE transactions SET status='PAID',provider_reference=?,paid_at=CURRENT_TIMESTAMP WHERE id=? AND status='PENDING'").run(providerRef,tx.id);
    const changed = db.prepare("SELECT changes() c").get().c;
    if (changed !== 1) throw new Error("IDEMPOTENCY");
    db.prepare("UPDATE candidates SET votes=votes+?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(tx.quantity,tx.candidate_id);
    db.prepare("INSERT INTO audit_logs(transaction_id,action,metadata) VALUES(?,?,?)").run(tx.id,"PAYMENT_CONFIRMED_DEMO",JSON.stringify({providerRef}));
  });
  try { finalize(); } catch(e) { return res.status(409).json({error:"Transaction déjà traitée"}); }
  res.json({transactionId:tx.id,status:"PAID",providerReference:providerRef,addedVotes:tx.quantity});
});

app.get("/api/ranking", (req,res) => {
  res.json({miss:ranking("MISS"), master:ranking("MASTER")});
});

app.post("/api/admin/login",(req,res)=>{
  const {email,password} = req.body;
  const admin = db.prepare("SELECT * FROM admins WHERE email=?").get(email);
  if (!admin || hashPassword(password || "") !== admin.password_hash) return res.status(401).json({error:"Identifiants incorrects"});
  const token = jwt.sign({id:admin.id,email:admin.email},JWT_SECRET,{expiresIn:"8h"});
  res.cookie("admin_token",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000});
  res.json({ok:true,email:admin.email});
});
app.post("/api/admin/logout",(req,res)=>{res.clearCookie("admin_token");res.json({ok:true})});
app.get("/api/admin/me",auth,(req,res)=>res.json({email:req.admin.email}));

app.get("/api/admin/summary",auth,(req,res)=>{
  const revenue = db.prepare("SELECT COALESCE(SUM(gross_amount),0) total FROM transactions WHERE status='PAID'").get().total;
  const commission = db.prepare("SELECT COALESCE(SUM(commission_amount),0) total FROM transactions WHERE status='PAID'").get().total;
  const contest = db.prepare("SELECT COALESCE(SUM(contest_amount),0) total FROM transactions WHERE status='PAID'").get().total;
  const votes = db.prepare("SELECT COALESCE(SUM(quantity),0) total FROM transactions WHERE status='PAID'").get().total;
  const pending = db.prepare("SELECT COUNT(*) c FROM transactions WHERE status='PENDING'").get().c;
  res.json({revenue,commission,contest,votes,pending,settings:getSettings()});
});

app.get("/api/admin/candidates",auth,(req,res)=>res.json(db.prepare("SELECT * FROM candidates ORDER BY category,number").all()));
app.post("/api/admin/candidates",auth,(req,res)=>{
  const {category,number,name,presentation,photo_url="",active=1}=req.body;
  try {
    const r=db.prepare("INSERT INTO candidates(category,number,name,presentation,photo_url,active) VALUES(?,?,?,?,?,?)").run(category,Number(number),name,presentation,photo_url,active?1:0);
    res.status(201).json(db.prepare("SELECT * FROM candidates WHERE id=?").get(r.lastInsertRowid));
  } catch(e){res.status(400).json({error:"Candidat invalide ou numéro déjà utilisé"})}
});
app.put("/api/admin/candidates/:id",auth,(req,res)=>{
  const {category,number,name,presentation,photo_url="",active=1}=req.body;
  try {
    db.prepare("UPDATE candidates SET category=?,number=?,name=?,presentation=?,photo_url=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(category,Number(number),name,presentation,photo_url,active?1:0,req.params.id);
    res.json(db.prepare("SELECT * FROM candidates WHERE id=?").get(req.params.id));
  } catch(e){res.status(400).json({error:"Modification invalide"})}
});
app.delete("/api/admin/candidates/:id",auth,(req,res)=>{
  db.prepare("UPDATE candidates SET active=0,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.put("/api/admin/settings",auth,(req,res)=>{
  const {vote_price,commission_type,commission_value}=req.body;
  if(!Number.isFinite(Number(vote_price)) || Number(vote_price)<1) return res.status(400).json({error:"Prix invalide"});
  if(!["FIXED","PERCENT"].includes(commission_type)) return res.status(400).json({error:"Type de commission invalide"});
  if(!Number.isFinite(Number(commission_value)) || Number(commission_value)<0) return res.status(400).json({error:"Commission invalide"});
  if(commission_type==="PERCENT" && Number(commission_value)>100) return res.status(400).json({error:"Pourcentage > 100"});
  for(const [k,v] of Object.entries({vote_price,commission_type,commission_value})) db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(k,String(v));
  res.json({ok:true,settings:getSettings()});
});

app.get("/api/admin/transactions",auth,(req,res)=>{
  res.json(db.prepare(`
    SELECT t.*, c.category, c.number, c.name candidate_name
    FROM transactions t JOIN candidates c ON c.id=t.candidate_id
    ORDER BY t.created_at DESC
  `).all());
});

app.get("/api/admin/export.csv",auth,(req,res)=>{
  const rows=db.prepare(`
    SELECT t.id,t.status,t.created_at,t.paid_at,c.category,c.number,c.name candidate,
    t.quantity,t.unit_price,t.gross_amount,t.commission_amount,t.contest_amount,
    t.customer_name,t.customer_phone,t.payment_method,t.provider_reference
    FROM transactions t JOIN candidates c ON c.id=t.candidate_id ORDER BY t.created_at DESC
  `).all();
  const header=Object.keys(rows[0]||{id:""}).join(",");
  const csv=[header,...rows.map(r=>Object.values(r).map(v=>`"${String(v??"").replaceAll('"','""')}"`).join(","))].join("\n");
  res.setHeader("Content-Type","text/csv; charset=utf-8");
  res.setHeader("Content-Disposition",'attachment; filename="transactions-vote-2026.csv"');
  res.send(csv);
});

app.get("/health",(req,res)=>res.json({ok:true,service:"GUINEE MISS & MASTER VOTE 2026",paymentMode:process.env.PAYMENT_MODE||"DEMO"}));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT,()=>console.log(`Vote 2026 running on http://localhost:${PORT}`));
