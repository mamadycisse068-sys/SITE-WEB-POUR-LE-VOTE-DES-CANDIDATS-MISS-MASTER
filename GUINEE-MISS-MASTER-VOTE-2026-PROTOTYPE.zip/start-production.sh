#!/usr/bin/env bash
set -e
npm install --omit=dev
node server.js
